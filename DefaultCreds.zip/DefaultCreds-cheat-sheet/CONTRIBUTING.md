## Guidelines

- Void / null, blank paswords are standardized as `<blank>`
- Sort Product/Vendor alphabetically `tail -n +2 DefaultCreds-Cheat-Sheet.csv | sort -u` 
- Look for duplicate before adding a new entry, eg. `3COM,admin,admin` and `3com,admin,admin` are the same so please red-use existing Vendor/product name
