## ssh keys
Default ssh keys for several products, extracted from routersploit project https://github.com/threat9/routersploit/tree/master/routersploit/resources/ssh_keys 

> Gathered here as a part of the project


Available key products:

  - array-networks-vapv-vxag       
  - ceragon-fibeair-cve-2015-0936  
  - loadbalancer.org-enterprise-va  
  - quantum-dxi-v1000
  - array-networks-vapv-vxag        
  - exagrid-cve-2016-1561         
  - loadbalancer.org-enterprise-va   
  - vagrant
  - barracuda_load_balancer_vm     
  - exagrid-cve-2016-1561          
  - monroe-dasdec-cve-2013-0137     
  - vagrant
  - barracuda_load_balancer_vm      
  - f5-bigip-cve-2012-1493        
  - monroe-dasdec-cve-2013-0137
  - ceragon-fibeair-cve-2015-0936  
  - f5-bigip-cve-2012-1493         
  - quantum-dxi-v1000

